'''
Syntax Highlighting
===================

This module contains various files for providing Kivy syntax highlighting in
some popular text editors. Please see the contents of this folder for the
provided resources.

'''
