def dostuff(n):
    t = 0
    for i in range(n):
        t += i
    return t
