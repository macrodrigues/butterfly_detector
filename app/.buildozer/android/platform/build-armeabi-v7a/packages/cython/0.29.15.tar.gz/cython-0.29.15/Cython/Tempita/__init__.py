# The original Tempita implements all of its templating code here.
# Moved it to _tempita.py to make the compilation portable.

from ._tempita import *
